/// <reference types="node" />
export declare class IdempotencyService {
    /**
     * Gera hash único baseado no conteúdo do arquivo
     * Útil para identificar se o mesmo arquivo foi processado antes
     */
    generateFileHash(content: Buffer | string): string;
    /**
     * Gera identificador único para o processamento
     * Combina bucket, key e timestamp
     */
    generateProcessingId(bucket: string, key: string): string;
}
//# sourceMappingURL=idempotency.d.ts.map