"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.IdempotencyService = void 0;
const crypto_1 = __importDefault(require("crypto"));
class IdempotencyService {
    /**
     * Gera hash único baseado no conteúdo do arquivo
     * Útil para identificar se o mesmo arquivo foi processado antes
     */
    generateFileHash(content) {
        return crypto_1.default.createHash("sha256").update(content).digest("hex");
    }
    /**
     * Gera identificador único para o processamento
     * Combina bucket, key e timestamp
     */
    generateProcessingId(bucket, key) {
        const timestamp = new Date().toISOString();
        const data = `${bucket}:${key}:${timestamp}`;
        return crypto_1.default.createHash("md5").update(data).digest("hex");
    }
}
exports.IdempotencyService = IdempotencyService;
//# sourceMappingURL=idempotency.js.map