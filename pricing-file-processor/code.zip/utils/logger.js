"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Logger = void 0;
const env_1 = require("../config/env");
class Logger {
    static info(message, meta) {
        console.log(JSON.stringify({
            level: "INFO",
            message,
            ...meta,
            timestamp: new Date().toISOString(),
        }));
    }
    static error(message, error, meta) {
        console.error(JSON.stringify({
            level: "ERROR",
            message,
            error: error?.message,
            stack: error?.stack,
            ...meta,
            timestamp: new Date().toISOString(),
        }));
    }
    static warn(message, meta) {
        console.warn(JSON.stringify({
            level: "WARN",
            message,
            ...meta,
            timestamp: new Date().toISOString(),
        }));
    }
    static debug(message, meta) {
        if (env_1.env.LOG_LEVEL === "debug") {
            console.debug(JSON.stringify({
                level: "DEBUG",
                message,
                ...meta,
                timestamp: new Date().toISOString(),
            }));
        }
    }
}
exports.Logger = Logger;
//# sourceMappingURL=logger.js.map