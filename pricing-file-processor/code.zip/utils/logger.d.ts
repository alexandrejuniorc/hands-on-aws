export declare class Logger {
    static info(message: string, meta?: Record<string, any>): void;
    static error(message: string, error?: Error, meta?: Record<string, any>): void;
    static warn(message: string, meta?: Record<string, any>): void;
    static debug(message: string, meta?: Record<string, any>): void;
}
//# sourceMappingURL=logger.d.ts.map