import { S3Event } from "aws-lambda";
export declare const handler: (event: S3Event) => Promise<void>;
//# sourceMappingURL=index.d.ts.map