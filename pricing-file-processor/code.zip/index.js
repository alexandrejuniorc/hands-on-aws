"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const uuid_1 = require("uuid");
const s3_service_1 = require("./services/s3.service");
const dynamodb_service_1 = require("./services/dynamodb.service");
const secrets_manager_service_1 = require("./services/secrets-manager.service");
const csv_parser_1 = require("./parsers/csv.parser");
const excel_parser_1 = require("./parsers/excel.parser");
const idempotency_1 = require("./utils/idempotency");
const logger_1 = require("./utils/logger");
const product_schema_validator_1 = require("./validators/product-schema.validator");
const s3Service = new s3_service_1.S3Service();
const dynamoService = new dynamodb_service_1.DynamoDBService();
const secretsService = new secrets_manager_service_1.SecretsManagerService();
const csvParser = new csv_parser_1.CSVParser();
const excelParser = new excel_parser_1.ExcelParser();
const idempotencyService = new idempotency_1.IdempotencyService();
const handler = async (event) => {
    logger_1.Logger.info("S3 Event received", { recordCount: event.Records.length });
    for (const record of event.Records) {
        const bucket = record.s3.bucket.name;
        const key = decodeURIComponent(record.s3.object.key.replace(/\+/g, " "));
        const processingId = idempotencyService.generateProcessingId(bucket, key);
        try {
            logger_1.Logger.info("Processing file", { bucket, key, processingId });
            // 1. Ler arquivo do S3
            const fileBuffer = await s3Service.getFileContent(bucket, key);
            const fileExtension = s3Service.getFileExtension(key);
            const fileHash = idempotencyService.generateFileHash(fileBuffer);
            logger_1.Logger.debug("File downloaded", {
                size: fileBuffer.length,
                extension: fileExtension,
                hash: fileHash,
            });
            // Validar tamanho (10MB max)
            const MAX_SIZE = 10 * 1024 * 1024; // 10MB
            if (fileBuffer.length > MAX_SIZE) {
                throw new Error(`File size ${fileBuffer.length} exceeds maximum ${MAX_SIZE} bytes`);
            }
            // 2. Parse baseado na extensão
            let parsedData;
            if (fileExtension === "csv") {
                logger_1.Logger.info("Parsing CSV file");
                parsedData = csvParser.parse(fileBuffer.toString("utf-8"));
            }
            else if (["xlsx", "xls"].includes(fileExtension)) {
                logger_1.Logger.info("Parsing Excel file");
                parsedData = excelParser.parse(fileBuffer);
            }
            else {
                throw new Error(`Unsupported file format: ${fileExtension}`);
            }
            logger_1.Logger.info("File parsed", { recordCount: parsedData.length });
            // 3. Validar cada item com Zod e adicionar UUID
            const validatedProducts = [];
            const errors = [];
            for (let i = 0; i < parsedData.length; i++) {
                try {
                    const validated = product_schema_validator_1.productSchema.parse(parsedData[i]);
                    validatedProducts.push({
                        id: (0, uuid_1.v4)(), // Gera ID único para cada produto
                        ...validated,
                        createdAt: new Date().toISOString(),
                        updatedAt: null,
                    });
                }
                catch (error) {
                    errors.push({
                        row: i + 1,
                        error: error.message,
                    });
                }
            }
            if (errors.length > 0) {
                logger_1.Logger.warn("Validation errors found", {
                    errorCount: errors.length,
                    errors: errors.slice(0, 10), // Log apenas os primeiros 10 erros
                });
            }
            if (validatedProducts.length === 0) {
                throw new Error("No valid products to insert after validation");
            }
            logger_1.Logger.info("Validation complete", {
                validCount: validatedProducts.length,
                errorCount: errors.length,
            });
            // 4. Buscar nome da tabela do Secrets Manager
            const tableName = await secretsService.getTableName();
            logger_1.Logger.info("Table name retrieved", { tableName });
            // 5. Inserir no DynamoDB (batch de 25 itens por vez)
            await dynamoService.batchWrite(tableName, validatedProducts);
            logger_1.Logger.info("Processing complete", {
                bucket,
                key,
                processingId,
                totalRecords: parsedData.length,
                successfulInserts: validatedProducts.length,
                failedValidations: errors.length,
            });
        }
        catch (error) {
            logger_1.Logger.error("Error processing file", error, {
                bucket,
                key,
                processingId,
            });
            throw error; // Lambda irá retentar ou enviar para DLQ
        }
    }
};
exports.handler = handler;
//# sourceMappingURL=index.js.map