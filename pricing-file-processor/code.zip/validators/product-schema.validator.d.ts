import { z } from "zod";
export declare const productSchema: z.ZodObject<{
    name: z.ZodString;
    description: z.ZodString;
    price: z.ZodNumber;
    quantity: z.ZodNumber;
}, "strip", z.ZodTypeAny, {
    name: string;
    description: string;
    price: number;
    quantity: number;
}, {
    name: string;
    description: string;
    price: number;
    quantity: number;
}>;
export type ProductInput = z.infer<typeof productSchema>;
export interface ProductRecord extends ProductInput {
    id: string;
    createdAt: string;
    updatedAt: string | null;
}
//# sourceMappingURL=product-schema.validator.d.ts.map