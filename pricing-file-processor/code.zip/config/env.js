"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.env = void 0;
const zod_1 = require("zod");
const envSchema = zod_1.z.object({
    AWS_DEFAULT_REGION: zod_1.z.string().default("us-east-2"),
    SECRET_NAME: zod_1.z.string().default("hands-on-aws/database"),
    NODE_ENV: zod_1.z.enum(["development", "production", "test"]).default("production"),
    LOG_LEVEL: zod_1.z.enum(["debug", "info", "warn", "error"]).default("info"),
});
function validateEnv() {
    try {
        return envSchema.parse(process.env);
    }
    catch (error) {
        if (error instanceof zod_1.z.ZodError) {
            const missingVars = error.errors
                .map((err) => `${err.path.join(".")}: ${err.message}`)
                .join("\n");
            throw new Error(`❌ Invalid environment variables:\n${missingVars}\n\nPlease check your .env file or Lambda environment variables.`);
        }
        throw error;
    }
}
exports.env = validateEnv();
//# sourceMappingURL=env.js.map