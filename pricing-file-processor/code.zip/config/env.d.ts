import { z } from "zod";
declare const envSchema: z.ZodObject<{
    AWS_DEFAULT_REGION: z.ZodDefault<z.ZodString>;
    SECRET_NAME: z.ZodDefault<z.ZodString>;
    NODE_ENV: z.ZodDefault<z.ZodEnum<["development", "production", "test"]>>;
    LOG_LEVEL: z.ZodDefault<z.ZodEnum<["debug", "info", "warn", "error"]>>;
}, "strip", z.ZodTypeAny, {
    AWS_DEFAULT_REGION: string;
    SECRET_NAME: string;
    NODE_ENV: "development" | "production" | "test";
    LOG_LEVEL: "debug" | "info" | "warn" | "error";
}, {
    AWS_DEFAULT_REGION?: string | undefined;
    SECRET_NAME?: string | undefined;
    NODE_ENV?: "development" | "production" | "test" | undefined;
    LOG_LEVEL?: "debug" | "info" | "warn" | "error" | undefined;
}>;
export type Env = z.infer<typeof envSchema>;
export declare const env: {
    AWS_DEFAULT_REGION: string;
    SECRET_NAME: string;
    NODE_ENV: "development" | "production" | "test";
    LOG_LEVEL: "debug" | "info" | "warn" | "error";
};
export {};
//# sourceMappingURL=env.d.ts.map