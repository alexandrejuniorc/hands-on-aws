"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.CSVParser = void 0;
const papaparse_1 = __importDefault(require("papaparse"));
class CSVParser {
    parse(fileContent) {
        const result = papaparse_1.default.parse(fileContent, {
            header: true,
            skipEmptyLines: true,
            dynamicTyping: true, // Converte números automaticamente
        });
        if (result.errors.length > 0) {
            console.warn("CSV parsing warnings:", result.errors);
        }
        return result.data.map((row) => ({
            name: String(row.name || ""),
            description: String(row.description || ""),
            price: Number(row.price || 0),
            quantity: Number(row.quantity || 0),
        }));
    }
}
exports.CSVParser = CSVParser;
//# sourceMappingURL=csv.parser.js.map