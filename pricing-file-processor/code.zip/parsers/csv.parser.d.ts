import { ProductInput } from "../validators/product-schema.validator";
export declare class CSVParser {
    parse(fileContent: string): ProductInput[];
}
//# sourceMappingURL=csv.parser.d.ts.map