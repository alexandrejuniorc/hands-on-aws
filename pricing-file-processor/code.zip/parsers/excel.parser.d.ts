/// <reference types="node" />
import { ProductInput } from "../validators/product-schema.validator";
export declare class ExcelParser {
    parse(buffer: Buffer): ProductInput[];
}
//# sourceMappingURL=excel.parser.d.ts.map