"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.DynamoDBService = void 0;
const client_dynamodb_1 = require("@aws-sdk/client-dynamodb");
const lib_dynamodb_1 = require("@aws-sdk/lib-dynamodb");
class DynamoDBService {
    constructor() {
        const client = new client_dynamodb_1.DynamoDBClient({
            region: process.env.AWS_REGION || "us-east-1",
        });
        this.docClient = lib_dynamodb_1.DynamoDBDocumentClient.from(client, {
            marshallOptions: { removeUndefinedValues: true },
        });
    }
    async batchWrite(tableName, items) {
        // DynamoDB BatchWrite limita a 25 itens por request
        const BATCH_SIZE = 25;
        const batches = this.chunkArray(items, BATCH_SIZE);
        console.log(`Writing ${items.length} items in ${batches.length} batches`);
        for (const batch of batches) {
            const putRequests = batch.map((item) => ({
                PutRequest: { Item: item },
            }));
            const command = new lib_dynamodb_1.BatchWriteCommand({
                RequestItems: {
                    [tableName]: putRequests,
                },
            });
            await this.docClient.send(command);
        }
    }
    chunkArray(array, size) {
        const chunks = [];
        for (let i = 0; i < array.length; i += size) {
            chunks.push(array.slice(i, i + size));
        }
        return chunks;
    }
}
exports.DynamoDBService = DynamoDBService;
//# sourceMappingURL=dynamodb.service.js.map