export declare class SecretsManagerService {
    private client;
    constructor();
    getSecret(secretName: string): Promise<Record<string, any>>;
    getTableName(): Promise<string>;
}
//# sourceMappingURL=secrets-manager.service.d.ts.map