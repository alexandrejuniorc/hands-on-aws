"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.S3Service = void 0;
const client_s3_1 = require("@aws-sdk/client-s3");
class S3Service {
    constructor() {
        this.client = new client_s3_1.S3Client({
            region: process.env.AWS_REGION || "us-east-1",
        });
    }
    async getFileContent(bucket, key) {
        const command = new client_s3_1.GetObjectCommand({ Bucket: bucket, Key: key });
        const response = await this.client.send(command);
        if (!response.Body) {
            throw new Error("Empty file content");
        }
        return Buffer.from(await response.Body.transformToByteArray());
    }
    getFileExtension(key) {
        return key.split(".").pop()?.toLowerCase() || "";
    }
}
exports.S3Service = S3Service;
//# sourceMappingURL=s3.service.js.map