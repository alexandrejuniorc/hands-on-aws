"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SecretsManagerService = void 0;
const client_secrets_manager_1 = require("@aws-sdk/client-secrets-manager");
const env_1 = require("../config/env");
const logger_1 = require("../utils/logger");
class SecretsManagerService {
    constructor() {
        this.client = new client_secrets_manager_1.SecretsManagerClient({
            region: env_1.env.AWS_DEFAULT_REGION,
        });
        logger_1.Logger.info("SecretsManager initialized", {
            region: env_1.env.AWS_DEFAULT_REGION,
            secretName: env_1.env.SECRET_NAME,
        });
    }
    async getSecret(secretName) {
        logger_1.Logger.info("Fetching secret", { secretName });
        const command = new client_secrets_manager_1.GetSecretValueCommand({ SecretId: secretName });
        const response = await this.client.send(command);
        if (!response.SecretString) {
            logger_1.Logger.error(`Secret not found or empty`, undefined, { secretName });
            throw new Error(`Secret ${secretName} not found`);
        }
        const secrets = JSON.parse(response.SecretString);
        const keys = Object.keys(secrets);
        logger_1.Logger.info("Secret fetched successfully", {
            secretName,
            keys: keys.join(", "),
            keysCount: keys.length,
        });
        return secrets;
    }
    async getTableName() {
        logger_1.Logger.debug("Getting PRODUCTS_TABLE_NAME from secret", {
            secretName: env_1.env.SECRET_NAME,
        });
        const secrets = await this.getSecret(env_1.env.SECRET_NAME);
        if (!secrets.PRODUCTS_TABLE) {
            const availableKeys = Object.keys(secrets).join(", ");
            logger_1.Logger.error("PRODUCTS_TABLE_NAME not found in secret", undefined, {
                availableKeys,
            });
            throw new Error(`PRODUCTS_TABLE_NAME not found in secrets. Available keys: ${availableKeys}`);
        }
        const tableName = secrets.PRODUCTS_TABLE;
        logger_1.Logger.info("Using DynamoDB table", { tableName });
        return tableName;
    }
}
exports.SecretsManagerService = SecretsManagerService;
//# sourceMappingURL=secrets-manager.service.js.map