import { ProductRecord } from "../validators/product-schema.validator";
export declare class DynamoDBService {
    private docClient;
    constructor();
    batchWrite(tableName: string, items: ProductRecord[]): Promise<void>;
    private chunkArray;
}
//# sourceMappingURL=dynamodb.service.d.ts.map