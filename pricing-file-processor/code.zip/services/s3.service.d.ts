/// <reference types="node" />
export declare class S3Service {
    private client;
    constructor();
    getFileContent(bucket: string, key: string): Promise<Buffer>;
    getFileExtension(key: string): string;
}
//# sourceMappingURL=s3.service.d.ts.map